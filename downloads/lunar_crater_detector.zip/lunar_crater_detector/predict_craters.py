#!/usr/bin/env python3
"""Run the compact lunar crater detector on one image or a directory."""
import argparse
import csv
from pathlib import Path
from ultralytics import YOLO


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("image", help="Input image file or directory")
    ap.add_argument("--weights", default=str(Path(__file__).with_name("crater_detector.pt")))
    ap.add_argument("--output", default="crater_predictions")
    ap.add_argument("--conf", type=float, default=0.25)
    ap.add_argument("--imgsz", type=int, default=416)
    args = ap.parse_args()

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    model = YOLO(args.weights)
    results = model.predict(
        source=args.image,
        imgsz=args.imgsz,
        conf=args.conf,
        max_det=1000,
        save=True,
        project=str(output),
        name="annotated",
        exist_ok=True,
        verbose=False,
    )
    csv_path = output / "detections.csv"
    with csv_path.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["image", "x1", "y1", "x2", "y2", "confidence"])
        for result in results:
            boxes = result.boxes
            if boxes is None:
                continue
            xyxy = boxes.xyxy.cpu().tolist()
            confs = boxes.conf.cpu().tolist()
            for box, score in zip(xyxy, confs):
                writer.writerow([Path(result.path).name, *[round(v, 2) for v in box], round(score, 4)])
    print(f"Annotated predictions: {output / 'annotated'}")
    print(f"Detection table: {csv_path}")


if __name__ == "__main__":
    main()
