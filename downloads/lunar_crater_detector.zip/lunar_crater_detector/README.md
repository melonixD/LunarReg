# Lunar crater detector (starter model)

A one-class YOLOv8n object detector fine-tuned for crater bounding boxes.

## Use

Install Python packages (`pip install ultralytics`), then run:

```bash
python predict_craters.py /path/to/lunar_image.png --conf 0.25
```

This writes annotated image(s) under `crater_predictions/annotated/` and a
`detections.csv` with pixel-space bounding boxes and confidence scores.

## Training and evaluation

- Base model: YOLOv8n pretrained checkpoint; fine-tuned for 20 CPU epochs at 416 px.
- Source training data: 248 labeled LRO NAC lunar tiles from Fairweather et al.,
  Zenodo record 6386198 (CC BY 4.0; https://doi.org/10.5281/zenodo.6386198).
- Split: 198 train / 50 validation tiles, seed 42.
- Validation (this random split): precision 0.683, recall 0.641,
  mAP@0.5 0.673, mAP@0.5:0.95 0.278.
- Important: the random tile split may include nearby/related scenes on both sides,
  so these scores may be optimistic. They are a baseline, not a mission-ready result.
- Sensor caveat: training imagery is LRO NAC, not Chandrayaan-2 IIR/NRI. Expect a
  domain gap; performance on the provided Chandrayaan screenshot is unvalidated.
  Re-training/adaptation on labeled IIR/NRI examples would be needed for a reliable
  Chandrayaan-specific detector.

The public training archive is available separately as `training_tiles.zip` (~13 MB).
