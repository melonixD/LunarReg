# Chandrayaan-2 (OHRC / TMC-2 / IIRS) imagery of the Chandrayaan-3 landing region

**Requested Area of Interest (AOI):**
- Latitude: 69.00°S to 69.70°S
- Longitude: 31.30°E to 33.30°E
- Time window requested: 1 Jan 2022 – 23 Aug 2023

This AOI is the **Chandrayaan-3 landing zone**. The Vikram lander touched down inside this box on
23 Aug 2023 at **Statio Shiv Shakti (69.373°S, 32.319°E)**, between the craters Manzinus C and
Simpelius N. The primary landing site (PLS) box used by ISRO was 4 km × 2.4 km centred at
69.367621°S, 32.348126°E — i.e. exactly inside your requested bounds.

## Important note about the raw archive (chmapbrowse.issdc.gov.in)

The MapBrowse portal and the underlying PRADAN archive (https://pradan.issdc.gov.in/ch2/) hold the
raw PDS-4 (.IMG) products for TMC-2, IIRS and OHRC covering this box, but they sit behind a **free
ISSDC user registration** — they cannot be downloaded anonymously, so this package contains the
**publicly released imagery** of the same region from official ISRO releases and open-access
ISRO-authored publications.

### How to get the raw PDS-4 products yourself (free)
1. Register at https://pradan.issdc.gov.in/ch2/ (free account).
2. Open https://chmapbrowse.issdc.gov.in/MapBrowse/ and sign in.
3. Switch Projection → **South Pole**.
4. Under *Instrument footprint*, enable `CH2_OHR_Calibrated_Product`, `CH2_TMC_*` and `CH2_IIR_*` layers.
5. Zoom/search to lat −69.0 to −69.7, lon 31.3 to 33.3; click a footprint → the left panel lists the
   PDS products with acquisition dates; filter to 2022-01-01 … 2023-08-23 and download (.IMG, PDS-4).
   Python users can read them with `pds4_tools`.

## Contents

### 01_OHRC — Orbiter High Resolution Camera (0.25–0.32 m/px)
| File | Description | Source / Credit |
|---|---|---|
| `OHRC_Chandrayaan3_Vikram_lander_20230823.jpg` (+ original .webp) | Vikram lander on the surface at Shiv Shakti Point, imaged by Chandrayaan-2 OHRC on **23 Aug 2023** (within your window). | ISRO (via Wikimedia Commons, GODL-India) |
| `OHRC_Fig1_south_pole_candidate_sites_S1-S8.png` | South-pole context map with the 8 candidate CH-3 sites characterized with OHRC; LS-2 (this AOI) became the prime site. | Amitabh et al., LPSC 2023 #1037 (SAC/ISRO) |
| `OHRC_Fig2_PLS_ortho_DEM_paintedDEM_4x2.4km.png` | OHRC ortho-image, 32 cm DEM and painted DEM of the 4 km × 2.4 km prime landing site (targeted OHRC stereo acquired pre-2023, i.e. in/near your window). | Amitabh et al., LPSC 2023 #1037 |
| `OHRC_Fig3_PLS_safe_grid_hazard_maps.png` | OHRC-derived hazard / safe-landing-grid maps of the PLS. | Amitabh et al., LPSC 2023 #1037 |
| `OHRC_MNRASL_Fig2_illumination_and_safe_grid_maps.png` | OHRC-derived illumination + safe-grid maps of the PLS. | Durga Prasad et al. 2023, MNRAS Letters 526, L116 |
| `OHRC_MNRASL_Fig3_ortho_DEM_slope_elevation_profiles.png` | OHRC ortho, DEM, colour-coded DEM, slope map and elevation profiles of the landing area. | Durga Prasad et al. 2023 |
| `OHRC_MNRASL_Fig4_geomorphic_units_69S21-69S24_32E15-32E25.png` | Geomorphic units of the landing area (69°21'–69°24'S, 32°15'–32°25'E) on OHRC imagery. | Durga Prasad et al. 2023 |
| `OHRC_MNRASL_Fig5_fresh_craters_boulders_map.png` | Fresh craters (green) and boulders (red) around the landing point (red star) on OHRC imagery. | Durga Prasad et al. 2023 |
| `MNRASL_Fig1_landing_site_context_LRO_WAC.png` | Candidate/selected landing sites over LRO-WAC south-pole mosaic (context). | Durga Prasad et al. 2023 |

### 02_TMC2_regional — Terrain Mapping Camera-2 (5 m/px) and regional context
Figures from Rajasekhar et al. 2024, *Icarus* 415, 116074 (ISRO/SAC), which characterized this AOI
using **TMC-2 ortho-images (5 m), TMC-1, OHRC, IIRS and DFSAR** plus LRO data. Panel-level
instrument attribution follows the paper's figure captions (regional image strips are TMC-2/LRO-WAC
based; local high-resolution insets are OHRC).
| File | Description |
|---|---|
| `Icarus2024_Fig1_south_polar_topography_context.jpg` | South-polar topography context map. |
| `Icarus2024_Fig2_regional_image_and_topography_LS_intercrater_plain.jpg` | Regional image + topography/slope of the inter-crater plain containing the landing site (~31–33°E). |
| `Icarus2024_Fig8_regional_image_strip_CH3_LS.jpg` | Regional image strip with CH-3 landing site marked. |
| `Icarus2024_Fig9_LS_region_image_annotated.jpg` | Annotated image of the landing-site region. |
| `Icarus2024_Fig10_LS_region_image_annotated.jpg` | Annotated image of the landing-site region. |

### 03_IIRS — Imaging Infrared Spectrometer (~80 m/px, 0.8–5 µm)
From Bhattacharya et al., LPSC 2024 #1915 (SAC-ISRO): the two IIRS strips that cover the CH-3
landing site (marked "CH-3 LS"), acquired **19 Jul 2021 (pre-landing)** and **3 Oct 2023
(post-landing)**. Note: these are the closest public IIRS acquisitions to your requested window —
no IIRS product of this box acquired strictly within Jan 2022–Aug 2023 has been publicly released
outside the login-protected PRADAN archive.
| File | Description |
|---|---|
| `IIRS_image_strips_pre2021-07-19_post2023-10-03_CH3_LS.png` | IIRS image strips (≈30.5–35.5°E, 69.5–70.5°S) covering the AOI. |
| `IIRS_surface_temperature_map_pre-landing.png` | IIRS-derived lunar surface temperature map (pre-landing illumination). |
| `IIRS_surface_temperature_map_post-landing.png` | IIRS-derived surface temperature map (post-landing illumination). |
| `IIRS_hydration_map_ppm_CH3_LS_region.png` | IIRS-derived surficial hydration (OH/H2O, ppm) map around the landing site (~0–50 ppm, mean ~20 ppm). |

### 04_spectral_thermal — supporting spectral/thermophysical products of the AOI
| File | Description | Source |
|---|---|---|
| `M3_albedo_1500nm_69-70S_32-33E_and_spectra.png` | 1°×1° albedo image at 1500 nm covering exactly 69–70°S / 32–33°E with representative reflectance spectra of the PLS. | Chandrayaan-1 M3; Durga Prasad et al. 2023 |
| `Modelled_surface_temperature_landing_area.png` | Local noon surface temperature over the 4.3 × 2.4 km landing area + diurnal min/max curves. | Durga Prasad et al. 2023 |
| `Modelled_temperature_200x200m_dawn.png` | Model-derived dawn temperature variation in a 200 × 200 m area at the landing site centre. | Durga Prasad et al. 2023 |

### 05_LRO_context — NASA LRO views of the same box (bonus, public domain)
| File | Description |
|---|---|
| `LROC_NAC_M1447750764LR_20230827_annotated.png` | LROC NAC image of the Vikram lander, 27 Aug 2023 (NASA/GSFC/ASU). |
| `LRO_landing_site_marked.png` | LRO imagery of the landing site, lander position marked. |

### papers/
Full source documents (all freely accessible) for provenance and full figure captions:
- Durga Prasad K. et al. (2023), "Contextual characterization study of Chandrayaan-3 primary landing site", MNRAS Letters 526, L116–L123, doi:10.1093/mnrasl/slad106 (open access).
- Amitabh et al. (2023), "Terrain Characterisation of Potential Landing Sites for Chandrayaan-3 Lander using OHRC Images", 54th LPSC, #1037.
- Bhattacharya S. et al. (2024), "Lunar Surface Temperature and Hydration Estimation Over the Chandrayaan-3 Landing Site Using Chandrayaan-2 IIRS...", 55th LPSC, #1915.

## Date-window notes
- **Within window:** OHRC image of Vikram lander (23 Aug 2023); OHRC targeted stereo observations of the PLS used for site characterization were acquired during 2021–2022 CH-3 site-selection campaigns (published Mar 2023).
- **Slightly outside window (flagged):** IIRS strips (19 Jul 2021 / 3 Oct 2023); LROC image (27 Aug 2023).
- Exact per-product acquisition timestamps for raw data require the PRADAN/MapBrowse metadata (free login, see above).

## Credits & licensing
ISRO imagery: © ISRO, generally reusable for non-commercial/educational purposes with attribution
(many releases also on Wikimedia Commons under GODL-India). Journal/LPSC figures: cite the papers
listed above. LRO imagery: NASA/GSFC/Arizona State University (public domain).
