from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import cv2
import numpy as np
import torch

from lunarreg.dataset import load_grayscale
from lunarreg.geometry import estimate_homography, uniform_select
from lunarreg.metrics import registration_metrics
from lunarreg.model import LunarDenseMatcher
from lunarreg.refine import refine_matches_ncc


def load_native(path: str) -> np.ndarray:
    image = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise RuntimeError(f"Could not read {path}")
    image = image.astype(np.float32)
    low, high = np.percentile(image, [1.0, 99.0])
    return np.clip((image - low) / max(high - low, 1e-6), 0.0, 1.0).astype(np.float32)


def preview_matches(source, reference, points0, points1, inliers) -> np.ndarray:
    left = (source * 255).astype(np.uint8)
    right = (reference * 255).astype(np.uint8)
    height = max(left.shape[0], right.shape[0])
    canvas = np.zeros((height, left.shape[1] + right.shape[1], 3), dtype=np.uint8)
    canvas[: left.shape[0], : left.shape[1]] = cv2.cvtColor(left, cv2.COLOR_GRAY2BGR)
    canvas[: right.shape[0], left.shape[1] :] = cv2.cvtColor(right, cv2.COLOR_GRAY2BGR)
    for p0, p1, valid in zip(points0, points1, inliers):
        color = (60, 220, 80) if valid else (60, 60, 220)
        a = tuple(np.round(p0).astype(int))
        b = tuple((np.round(p1) + np.array([left.shape[1], 0])).astype(int))
        cv2.line(canvas, a, b, color, 1, cv2.LINE_AA)
        cv2.circle(canvas, a, 2, color, -1, cv2.LINE_AA)
        cv2.circle(canvas, b, 2, color, -1, cv2.LINE_AA)
    return canvas


def main() -> None:
    parser = argparse.ArgumentParser(description="Register a lunar source image to a reference")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--reference", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--confidence", type=float, default=0.04)
    parser.add_argument("--magsac-threshold", type=float, default=2.0)
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(args.checkpoint, map_location=device)
    config = checkpoint["config"]
    size = int(config["data"]["image_size"])
    model = LunarDenseMatcher(**config["model"]).to(device)
    model.load_state_dict(checkpoint["model"])
    model.eval()

    source_native = load_native(args.source)
    reference_native = load_native(args.reference)
    source_model = load_grayscale(args.source, size)
    reference_model = load_grayscale(args.reference, size)
    tensor0 = torch.from_numpy(source_model[None, None]).float().to(device)
    tensor1 = torch.from_numpy(reference_model[None, None]).float().to(device)
    prediction = model.matches(tensor0, tensor1, args.confidence)["batches"][0]
    points0 = prediction["points0"].cpu().numpy()
    points1 = prediction["points1"].cpu().numpy()
    confidence = prediction["confidence"].cpu().numpy()

    points0 *= np.array([source_native.shape[1] / size, source_native.shape[0] / size], dtype=np.float32)
    points1 *= np.array([reference_native.shape[1] / size, reference_native.shape[0] / size], dtype=np.float32)
    points0, points1, confidence = uniform_select(
        points0, points1, confidence, source_native.shape, grid=8, per_cell=5
    )
    initial_h, initial_inliers = estimate_homography(points0, points1, args.magsac_threshold)
    if initial_h is None:
        raise RuntimeError(f"Registration failed: only {len(points0)} usable matches")

    projected = cv2.perspectiveTransform(points0.reshape(-1, 1, 2), initial_h).reshape(-1, 2)
    refined_points1, ncc_scores = refine_matches_ncc(
        source_native, reference_native, points0, projected, patch_size=15, search_radius=6
    )
    valid_ncc = ncc_scores > 0.05
    final_h, final_inliers = estimate_homography(
        points0[valid_ncc], refined_points1[valid_ncc], max(0.75, args.magsac_threshold / 2)
    )
    if final_h is None:
        final_h = initial_h
        refined_points1 = points1
        final_inliers = initial_inliers
        valid_ncc = np.ones(len(points0), dtype=bool)
    selected0 = points0[valid_ncc]
    selected1 = refined_points1[valid_ncc]
    metrics = registration_metrics(selected0, selected1, final_h, final_inliers, source_native.shape)

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    registered = cv2.warpPerspective(
        (source_native * 255).astype(np.uint8),
        final_h,
        (reference_native.shape[1], reference_native.shape[0]),
        flags=cv2.INTER_CUBIC,
    )
    cv2.imwrite(str(output / "registered.png"), registered)
    cv2.imwrite(
        str(output / "matches_preview.png"),
        preview_matches(source_native, reference_native, selected0, selected1, final_inliers),
    )
    with open(output / "matches.csv", "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["source_x", "source_y", "reference_x", "reference_y", "inlier"])
        for p0, p1, inlier in zip(selected0, selected1, final_inliers):
            writer.writerow([float(p0[0]), float(p0[1]), float(p1[0]), float(p1[1]), int(inlier)])
    with open(output / "metrics.json", "w", encoding="utf-8") as handle:
        json.dump(metrics, handle, indent=2)
    with open(output / "homography.json", "w", encoding="utf-8") as handle:
        json.dump({"source_to_reference": final_h.tolist()}, handle, indent=2)
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()

