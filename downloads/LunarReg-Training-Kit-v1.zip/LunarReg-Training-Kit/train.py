from __future__ import annotations

import argparse
import csv
import random
import shutil
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from lunarreg.config import load_config
from lunarreg.dataset import LunarPairDataset
from lunarreg.losses import matching_loss
from lunarreg.model import LunarDenseMatcher


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def build_dataset(config: dict, split: str) -> LunarPairDataset:
    data = config["data"]
    count = data["samples_per_epoch"] if split == "train" else data["validation_samples"]
    seed = config["run"]["seed"] + (0 if split == "train" else 900001)
    return LunarPairDataset(
        roots=data["roots"],
        image_size=data["image_size"],
        samples_per_epoch=count,
        seed=seed,
        difficulty=data.get("difficulty", 1.0),
        paired_manifest=data.get("paired_manifest"),
        real_pair_probability=data.get("real_pair_probability", 0.0),
        split=split,
    )


def run_epoch(model, loader, optimizer, scaler, device, config, train: bool, writer, global_step: int):
    model.train(train)
    accumulation = int(config["training"].get("gradient_accumulation", 1))
    use_amp = bool(config["training"].get("mixed_precision", True)) and device.type == "cuda"
    totals = {"loss": 0.0, "coarse_loss": 0.0, "fine_loss": 0.0, "valid_fraction": 0.0}
    batches = 0
    if train:
        optimizer.zero_grad(set_to_none=True)

    context = torch.enable_grad if train else torch.no_grad
    with context():
        progress = tqdm(loader, desc="train" if train else "validate", leave=False)
        for batch_index, batch in enumerate(progress):
            image0 = batch["image0"].to(device, non_blocking=True)
            image1 = batch["image1"].to(device, non_blocking=True)
            homography = batch["homography"].to(device, non_blocking=True)
            sample_weight = batch["sample_weight"].to(device, non_blocking=True)
            with torch.autocast(device_type=device.type, enabled=use_amp, dtype=torch.float16):
                output = model(image0, image1)
                loss, metrics = matching_loss(output, homography, sample_weight, model.stride)
                scaled_loss = loss / accumulation

            if train:
                scaler.scale(scaled_loss).backward()
                should_step = (batch_index + 1) % accumulation == 0 or batch_index + 1 == len(loader)
                if should_step:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), config["training"].get("gradient_clip", 1.0))
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad(set_to_none=True)
                    global_step += 1
                    writer.add_scalar("train/loss_step", float(loss.detach()), global_step)

            for key in totals:
                totals[key] += float(metrics[key])
            batches += 1
            progress.set_postfix(loss=f"{float(loss):.4f}")

    averages = {key: value / max(batches, 1) for key, value in totals.items()}
    return averages, global_step


def save_checkpoint(path: Path, model, optimizer, scaler, epoch: int, best_loss: float, config: dict) -> None:
    torch.save(
        {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scaler": scaler.state_dict(),
            "epoch": epoch,
            "best_validation_loss": best_loss,
            "config": config,
        },
        path,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the LunarReg dense matcher")
    parser.add_argument("--config", required=True)
    parser.add_argument("--resume")
    args = parser.parse_args()

    config = load_config(args.config)
    seed_everything(int(config["run"]["seed"]))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    output_dir = Path(config["run"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.config, output_dir / "config.yaml")

    train_dataset = build_dataset(config, "train")
    validation_dataset = build_dataset(config, "validation")
    workers = int(config["data"].get("workers", 4))
    batch_size = int(config["training"]["batch_size"])
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=workers,
        pin_memory=device.type == "cuda",
        persistent_workers=workers > 0,
    )
    validation_loader = DataLoader(
        validation_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=max(0, workers // 2),
        pin_memory=device.type == "cuda",
    )

    model = LunarDenseMatcher(**config["model"]).to(device)
    encoder_parameters = list(model.encoder.parameters())
    encoder_ids = {id(parameter) for parameter in encoder_parameters}
    matcher_parameters = [parameter for parameter in model.parameters() if id(parameter) not in encoder_ids]
    optimizer = torch.optim.AdamW(
        [
            {"params": encoder_parameters, "lr": config["training"]["encoder_learning_rate"]},
            {"params": matcher_parameters, "lr": config["training"]["learning_rate"]},
        ],
        weight_decay=config["training"].get("weight_decay", 1e-4),
    )
    use_amp = bool(config["training"].get("mixed_precision", True)) and device.type == "cuda"
    scaler = torch.cuda.amp.GradScaler(enabled=use_amp)
    writer = SummaryWriter(output_dir / "tensorboard")

    start_epoch = 0
    best_loss = float("inf")
    if args.resume:
        checkpoint = torch.load(args.resume, map_location=device)
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        if "scaler" in checkpoint:
            scaler.load_state_dict(checkpoint["scaler"])
        start_epoch = int(checkpoint.get("epoch", -1)) + 1
        best_loss = float(checkpoint.get("best_validation_loss", best_loss))

    history_path = output_dir / "history.csv"
    if not history_path.exists():
        with open(history_path, "w", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerow(
                ["epoch", "train_loss", "validation_loss", "coarse_loss", "fine_loss", "valid_fraction"]
            )

    print(f"Device: {device}")
    print(f"Trainable parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")
    global_step = 0
    for epoch in range(start_epoch, int(config["training"]["epochs"])):
        train_metrics, global_step = run_epoch(
            model, train_loader, optimizer, scaler, device, config, True, writer, global_step
        )
        validation_metrics, global_step = run_epoch(
            model, validation_loader, optimizer, scaler, device, config, False, writer, global_step
        )
        writer.add_scalar("epoch/train_loss", train_metrics["loss"], epoch)
        writer.add_scalar("epoch/validation_loss", validation_metrics["loss"], epoch)
        with open(history_path, "a", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerow(
                [
                    epoch,
                    train_metrics["loss"],
                    validation_metrics["loss"],
                    validation_metrics["coarse_loss"],
                    validation_metrics["fine_loss"],
                    validation_metrics["valid_fraction"],
                ]
            )
        save_checkpoint(output_dir / "last.pt", model, optimizer, scaler, epoch, best_loss, config)
        if validation_metrics["loss"] < best_loss:
            best_loss = validation_metrics["loss"]
            save_checkpoint(output_dir / "best.pt", model, optimizer, scaler, epoch, best_loss, config)
        print(
            f"Epoch {epoch + 1}: train={train_metrics['loss']:.4f} "
            f"validation={validation_metrics['loss']:.4f} best={best_loss:.4f}"
        )
    writer.close()


if __name__ == "__main__":
    main()

