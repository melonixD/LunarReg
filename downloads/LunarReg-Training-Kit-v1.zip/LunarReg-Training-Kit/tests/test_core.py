import unittest

import numpy as np

from lunarreg.augment import apply_perlin_illumination, perlin_noise_2d
from lunarreg.geometry import coverage_ratio, transform_points, uniform_select


class CoreTests(unittest.TestCase):
    def test_perlin_is_deterministic_and_finite(self):
        first = perlin_noise_2d((64, 64), (4, 4), np.random.default_rng(12))
        second = perlin_noise_2d((64, 64), (4, 4), np.random.default_rng(12))
        self.assertEqual(first.shape, (64, 64))
        self.assertTrue(np.isfinite(first).all())
        self.assertTrue(np.allclose(first, second))

    def test_perlin_illumination_keeps_range(self):
        image = np.full((64, 64), 0.5, dtype=np.float32)
        result = apply_perlin_illumination(image, np.random.default_rng(1))
        self.assertGreaterEqual(float(result.min()), 0.0)
        self.assertLessEqual(float(result.max()), 1.0)
        self.assertGreater(float(result.std()), 0.001)

    def test_homography_point_mapping(self):
        homography = np.array([[1, 0, 5], [0, 1, -3], [0, 0, 1]], dtype=np.float32)
        points = np.array([[10, 10], [20, 30]], dtype=np.float32)
        expected = np.array([[15, 7], [25, 27]], dtype=np.float32)
        self.assertTrue(np.allclose(transform_points(points, homography), expected))

    def test_uniform_selection_limits_cells(self):
        points = np.array([[5, 5], [6, 6], [75, 75], [76, 76]], dtype=np.float32)
        confidence = np.array([0.9, 0.8, 0.7, 0.6], dtype=np.float32)
        p0, _, _ = uniform_select(points, points, confidence, (100, 100), grid=2, per_cell=1)
        self.assertEqual(len(p0), 2)
        self.assertEqual(coverage_ratio(p0, (100, 100), grid=2), 0.5)


if __name__ == "__main__":
    unittest.main()

