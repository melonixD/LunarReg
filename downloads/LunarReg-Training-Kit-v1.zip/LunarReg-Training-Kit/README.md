# LunarReg Training Kit

Training and inference pipeline for SIH26166-style lunar image correspondence:
Chandrayaan-2 OHRC/TMC-2/IIRS source images against LRO/SELENE references.

The repository contains a trainable dense matcher, synthetic homography ground
truth, Perlin illumination augmentation, pseudo-label bootstrapping with
pretrained LoFTR, uniform match selection, MAGSAC++ homography estimation and
local sub-pixel NCC refinement.

## Important limitation

The official paired evaluation dataset is not bundled. Place legally obtained
images in `data/raw/` and keep their original metadata. The included demo data
only verifies that the software runs; it does not train a competition model.

## 1. RunPod setup

Use a PyTorch CUDA template with a persistent 50-100 GB volume.

```bash
git clone <your-repository-url> LunarReg-Training-Kit
cd LunarReg-Training-Kit
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Verify the GPU:

```bash
python -c "import torch; print(torch.cuda.get_device_name()); print(torch.cuda.is_available())"
```

## 2. Add lunar images

```text
data/raw/ohrc/
data/raw/tmc2/
data/raw/iirs/
data/raw/lro/
data/raw/selene/
```

Supported preprocessing inputs are PNG, JPEG, TIFF and GeoTIFF readable by
OpenCV. Preserve the original PDS/GeoTIFF products outside this directory.

Create 512-pixel tiles:

```bash
python scripts/prepare_tiles.py \
  --input data/raw/ohrc \
  --output data/tiles/ohrc \
  --size 512 --overlap 64 --min-std 0.025

python scripts/prepare_tiles.py \
  --input data/raw/lro \
  --output data/tiles/lro \
  --size 512 --overlap 64 --min-std 0.025
```

## 3. Smoke test before renting a long GPU session

```bash
python scripts/make_demo_data.py
python train.py --config configs/smoke.yaml
python infer.py \
  --checkpoint runs/smoke/best.pt \
  --source data/demo/source.png \
  --reference data/demo/reference.png \
  --output runs/demo_inference
```

The smoke configuration is deliberately tiny. Its only purpose is to catch
installation, data-loader and checkpoint errors.

## 4. Train the first real model

Start with single-sensor synthetic supervision. Point `data.roots` to one or
more tile directories. A fresh homography and photometric transformation is
generated for every sample on every epoch.

```bash
python train.py --config configs/train_5090.yaml
```

For an RTX PRO 5000, use:

```bash
python train.py --config configs/train_pro5000.yaml
```

Resume safely:

```bash
python train.py --config configs/train_5090.yaml \
  --resume runs/lunar_5090/last.pt
```

Monitor:

```bash
tensorboard --logdir runs
```

## 5. Bootstrap real OHRC-LRO pairs

Create `data/manifests/candidates.csv`:

```csv
pair_id,source_path,reference_path,split
pair_0001,data/tiles/ohrc/a.png,data/tiles/lro/a.png,train
```

The two images should cover approximately the same lunar location. Then run:

```bash
python scripts/pseudo_label_loftr.py \
  --manifest data/manifests/candidates.csv \
  --output data/manifests/pseudo_pairs.csv \
  --preview-dir data/pseudo_previews
```

Inspect every preview. Delete incorrect rows. Each accepted row stores a
homography and can be mixed into training by setting `data.paired_manifest` in
the YAML configuration. Pseudo-labelled samples receive a lower loss weight.

## 6. Outputs

Training creates:

```text
runs/<name>/
├── best.pt
├── last.pt
├── config.yaml
├── history.csv
└── tensorboard/
```

Inference creates:

```text
registered.png
matches.csv
matches_preview.png
metrics.json
homography.json
```

## Recommended training sequence

1. Overfit 100 synthetic pairs using `configs/smoke.yaml`.
2. Train OHRC-only and LRO-only synthetic pairs for 10-15 epochs.
3. Generate and manually inspect OHRC-LRO pseudo-labels.
4. Mix 70% synthetic and 30% accepted real pairs for another 5-10 epochs.
5. Add TMC-2 only after OHRC-LRO validation is stable.
6. Add IIRS last because its spectral appearance can differ substantially.
7. Keep the test split separated by lunar geography, not random tiles.

## Acceptance checks

- The training loss decreases and a 100-pair subset can be overfit.
- Held-out synthetic PCK@3 exceeds 90% before real adaptation.
- Real pairs have at least 30 MAGSAC++ inliers distributed across the image.
- Median real-pair reprojection error is below one pixel after refinement.
- No parent mosaic/crater appears in both train and test splits.

## Why both a neural matcher and geometry are used

The neural model proposes correspondences. MAGSAC++ rejects inconsistent
matches and estimates the projective transform. Local gradient NCC then refines
coordinates to fractional-pixel precision. Perlin noise is used only for
smooth illumination augmentation; it is never treated as registration truth.

