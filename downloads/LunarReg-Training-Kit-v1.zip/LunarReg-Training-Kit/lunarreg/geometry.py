from __future__ import annotations

from typing import Dict, Tuple

import numpy as np


def transform_points(points: np.ndarray, homography: np.ndarray) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32)
    ones = np.ones((len(points), 1), dtype=np.float32)
    homogeneous = np.concatenate([points, ones], axis=1)
    mapped = homogeneous @ np.asarray(homography, dtype=np.float32).T
    return mapped[:, :2] / np.clip(mapped[:, 2:3], 1e-8, None)


def grid_centers(height: int, width: int, stride: int) -> np.ndarray:
    ys = np.arange(stride / 2.0, height, stride, dtype=np.float32)
    xs = np.arange(stride / 2.0, width, stride, dtype=np.float32)
    yy, xx = np.meshgrid(ys, xs, indexing="ij")
    return np.stack([xx.reshape(-1), yy.reshape(-1)], axis=1)


def uniform_select(
    points0: np.ndarray,
    points1: np.ndarray,
    confidence: np.ndarray,
    image_shape: Tuple[int, int],
    grid: int = 8,
    per_cell: int = 4,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    if len(points0) == 0:
        return points0, points1, confidence
    height, width = image_shape
    order = np.argsort(-confidence)
    counts: Dict[Tuple[int, int], int] = {}
    keep = []
    for idx in order:
        x, y = points0[idx]
        gx = min(grid - 1, max(0, int(x / max(width, 1) * grid)))
        gy = min(grid - 1, max(0, int(y / max(height, 1) * grid)))
        cell = (gx, gy)
        if counts.get(cell, 0) >= per_cell:
            continue
        counts[cell] = counts.get(cell, 0) + 1
        keep.append(idx)
    keep_arr = np.asarray(keep, dtype=np.int64)
    return points0[keep_arr], points1[keep_arr], confidence[keep_arr]


def estimate_homography(
    points0: np.ndarray,
    points1: np.ndarray,
    threshold: float = 2.0,
) -> Tuple[np.ndarray | None, np.ndarray]:
    import cv2

    if len(points0) < 4:
        return None, np.zeros(len(points0), dtype=bool)
    homography, mask = cv2.findHomography(
        points0.astype(np.float32),
        points1.astype(np.float32),
        method=cv2.USAC_MAGSAC,
        ransacReprojThreshold=float(threshold),
        maxIters=10000,
        confidence=0.999,
    )
    if homography is None or mask is None:
        return None, np.zeros(len(points0), dtype=bool)
    return homography.astype(np.float64), mask.reshape(-1).astype(bool)


def homography_errors(
    points0: np.ndarray,
    points1: np.ndarray,
    homography: np.ndarray,
) -> np.ndarray:
    prediction = transform_points(points0, homography)
    return np.linalg.norm(prediction - points1, axis=1)


def coverage_ratio(points: np.ndarray, image_shape: Tuple[int, int], grid: int = 8) -> float:
    if not len(points):
        return 0.0
    height, width = image_shape
    cells = set()
    for x, y in points:
        gx = min(grid - 1, max(0, int(x / max(width, 1) * grid)))
        gy = min(grid - 1, max(0, int(y / max(height, 1) * grid)))
        cells.add((gx, gy))
    return len(cells) / float(grid * grid)

