"""LunarReg training and registration package."""

__version__ = "1.0.0"

