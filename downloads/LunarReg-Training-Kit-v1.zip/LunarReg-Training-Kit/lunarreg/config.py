from __future__ import annotations

from pathlib import Path

import yaml


def load_config(path: str) -> dict:
    with open(path, encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    config["_config_path"] = str(Path(path).resolve())
    return config

