from __future__ import annotations

import torch
from torch.nn import functional as F


def token_grid(height: int, width: int, stride: int, device, dtype) -> torch.Tensor:
    y, x = torch.meshgrid(
        (torch.arange(height, device=device, dtype=dtype) + 0.5) * stride,
        (torch.arange(width, device=device, dtype=dtype) + 0.5) * stride,
        indexing="ij",
    )
    return torch.stack([x.reshape(-1), y.reshape(-1)], dim=-1)


def warp_points(points: torch.Tensor, homography: torch.Tensor) -> torch.Tensor:
    batch = homography.shape[0]
    expanded = points.unsqueeze(0).expand(batch, -1, -1)
    ones = torch.ones((*expanded.shape[:-1], 1), device=points.device, dtype=points.dtype)
    homogeneous = torch.cat([expanded, ones], dim=-1)
    mapped = torch.einsum("bij,bnj->bni", homography, homogeneous)
    return mapped[..., :2] / mapped[..., 2:3].clamp_min(1e-6)


def directional_loss(
    logits: torch.Tensor,
    homography: torch.Tensor,
    grid_height: int,
    grid_width: int,
    stride: int,
    sample_weight: torch.Tensor,
) -> tuple[torch.Tensor, dict]:
    device, dtype = logits.device, logits.dtype
    grid = token_grid(grid_height, grid_width, stride, device, dtype)
    mapped = warp_points(grid, homography.to(dtype))
    tx = torch.floor(mapped[..., 0] / stride).long()
    ty = torch.floor(mapped[..., 1] / stride).long()
    valid = (tx >= 0) & (tx < grid_width) & (ty >= 0) & (ty < grid_height)
    target = (ty.clamp(0, grid_height - 1) * grid_width + tx.clamp(0, grid_width - 1)).long()

    log_probability = F.log_softmax(logits.float(), dim=-1)
    nll = -log_probability.gather(-1, target.unsqueeze(-1)).squeeze(-1)
    weights = sample_weight.reshape(-1, 1).to(nll.dtype) * valid.to(nll.dtype)
    coarse = (nll * weights).sum() / weights.sum().clamp_min(1.0)

    probability = torch.softmax(logits.float(), dim=-1)
    predicted = torch.einsum("bnm,mc->bnc", probability, grid.float())
    fine_error = F.smooth_l1_loss(predicted, mapped.float(), reduction="none").sum(dim=-1)
    fine = (fine_error * weights).sum() / weights.sum().clamp_min(1.0)
    metrics = {
        "valid_fraction": valid.float().mean().detach(),
        "coarse_loss": coarse.detach(),
        "fine_loss": fine.detach(),
    }
    return coarse + 0.05 * fine, metrics


def matching_loss(output: dict, homography: torch.Tensor, sample_weight: torch.Tensor, stride: int) -> tuple:
    logits = output["logits"]
    height = int(output["grid_height"])
    width = int(output["grid_width"])
    forward_loss, forward_metrics = directional_loss(
        logits, homography, height, width, stride, sample_weight
    )
    inverse = torch.linalg.inv(homography.double()).to(homography.dtype)
    backward_loss, backward_metrics = directional_loss(
        logits.transpose(1, 2), inverse, height, width, stride, sample_weight
    )
    total = 0.5 * (forward_loss + backward_loss)
    metrics = {
        "loss": total.detach(),
        "coarse_loss": 0.5 * (forward_metrics["coarse_loss"] + backward_metrics["coarse_loss"]),
        "fine_loss": 0.5 * (forward_metrics["fine_loss"] + backward_metrics["fine_loss"]),
        "valid_fraction": 0.5 * (
            forward_metrics["valid_fraction"] + backward_metrics["valid_fraction"]
        ),
    }
    return total, metrics

