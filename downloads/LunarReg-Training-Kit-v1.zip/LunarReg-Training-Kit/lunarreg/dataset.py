from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Iterable, List, Optional

import numpy as np

from .augment import photometric_augment, sample_homography, warp_image


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}


def discover_images(roots: Iterable[str]) -> List[Path]:
    images: List[Path] = []
    for root in roots:
        path = Path(root)
        if not path.exists():
            continue
        images.extend(p for p in path.rglob("*") if p.suffix.lower() in IMAGE_EXTENSIONS)
    return sorted(images)


def load_grayscale(path: str | Path, size: int) -> np.ndarray:
    import cv2

    image = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if image is None:
        raise RuntimeError(f"Could not read image: {path}")
    if image.ndim == 3:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    image = image.astype(np.float32)
    low, high = np.percentile(image, [1.0, 99.0])
    if high <= low:
        high = low + 1.0
    image = np.clip((image - low) / (high - low), 0.0, 1.0)
    image = cv2.resize(image, (size, size), interpolation=cv2.INTER_AREA)
    return image.astype(np.float32)


def parse_homography(row: dict) -> Optional[np.ndarray]:
    if row.get("homography"):
        value = row["homography"].strip()
        try:
            data = json.loads(value)
            matrix = np.asarray(data, dtype=np.float32).reshape(3, 3)
            return matrix
        except (json.JSONDecodeError, ValueError):
            parts = [float(x) for x in value.replace(";", " ").replace(",", " ").split()]
            if len(parts) == 9:
                return np.asarray(parts, dtype=np.float32).reshape(3, 3)
    keys = [f"h{r}{c}" for r in range(3) for c in range(3)]
    if all(row.get(key, "") != "" for key in keys):
        return np.asarray([float(row[key]) for key in keys], dtype=np.float32).reshape(3, 3)
    return None


class LunarPairDataset:
    """On-the-fly synthetic pairs with optional real homography-labelled pairs."""

    def __init__(
        self,
        roots: Iterable[str],
        image_size: int,
        samples_per_epoch: int,
        seed: int = 42,
        difficulty: float = 1.0,
        paired_manifest: Optional[str] = None,
        real_pair_probability: float = 0.3,
        split: str = "train",
    ) -> None:
        import torch

        self.torch = torch
        self.images = discover_images(roots)
        self.image_size = int(image_size)
        self.samples_per_epoch = int(samples_per_epoch)
        self.seed = int(seed)
        self.difficulty = float(difficulty)
        self.real_pair_probability = float(real_pair_probability)
        self.split = split
        self.real_pairs = []
        if paired_manifest and Path(paired_manifest).exists():
            with open(paired_manifest, newline="", encoding="utf-8") as handle:
                for row in csv.DictReader(handle):
                    if row.get("split", split) != split:
                        continue
                    homography = parse_homography(row)
                    if homography is not None:
                        self.real_pairs.append((row["source_path"], row["reference_path"], homography))
        if not self.images and not self.real_pairs:
            raise FileNotFoundError(
                "No training images found. Add tiles under data/tiles or run scripts/make_demo_data.py."
            )

    def __len__(self) -> int:
        return self.samples_per_epoch

    def _rng(self, index: int) -> np.random.Generator:
        worker = self.torch.utils.data.get_worker_info()
        worker_id = 0 if worker is None else worker.id
        return np.random.default_rng(self.seed + index * 104729 + worker_id * 1000003)

    def __getitem__(self, index: int) -> dict:
        rng = self._rng(index)
        use_real = bool(self.real_pairs) and rng.random() < self.real_pair_probability
        if use_real:
            source_path, reference_path, homography = self.real_pairs[int(rng.integers(len(self.real_pairs)))]
            source = load_grayscale(source_path, self.image_size)
            reference = load_grayscale(reference_path, self.image_size)
            sample_weight = 0.35
            pair_type = "real"
        else:
            path = self.images[int(rng.integers(len(self.images)))]
            source = load_grayscale(path, self.image_size)
            homography = sample_homography(self.image_size, rng, self.difficulty)
            reference, _ = warp_image(source, homography, self.image_size)
            source = photometric_augment(source, rng) if rng.random() < 0.35 else source
            reference = photometric_augment(reference, rng)
            sample_weight = 1.0
            pair_type = "synthetic"

        source_tensor = self.torch.from_numpy(source[None]).float()
        reference_tensor = self.torch.from_numpy(reference[None]).float()
        return {
            "image0": source_tensor,
            "image1": reference_tensor,
            "homography": self.torch.from_numpy(homography).float(),
            "sample_weight": self.torch.tensor(sample_weight, dtype=self.torch.float32),
            "pair_type": pair_type,
        }

