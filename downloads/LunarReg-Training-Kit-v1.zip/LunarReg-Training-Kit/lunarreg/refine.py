from __future__ import annotations

from typing import Tuple

import numpy as np


def _gradient_image(image: np.ndarray) -> np.ndarray:
    import cv2

    gx = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=3)
    return cv2.magnitude(gx, gy)


def _ncc(first: np.ndarray, second: np.ndarray) -> float:
    a = first.astype(np.float32) - float(first.mean())
    b = second.astype(np.float32) - float(second.mean())
    denominator = float(np.sqrt(np.sum(a * a) * np.sum(b * b)) + 1e-8)
    return float(np.sum(a * b) / denominator)


def _quadratic_offset(left: float, center: float, right: float) -> float:
    denominator = left - 2.0 * center + right
    if abs(denominator) < 1e-8:
        return 0.0
    return float(np.clip(0.5 * (left - right) / denominator, -0.5, 0.5))


def refine_matches_ncc(
    source: np.ndarray,
    reference: np.ndarray,
    points0: np.ndarray,
    initial_points1: np.ndarray,
    patch_size: int = 15,
    search_radius: int = 5,
) -> Tuple[np.ndarray, np.ndarray]:
    """Refine target coordinates with gradient NCC and parabolic sub-pixel fitting."""
    src_grad = _gradient_image(source)
    ref_grad = _gradient_image(reference)
    half = patch_size // 2
    refined = initial_points1.astype(np.float32).copy()
    scores = np.full(len(points0), -1.0, dtype=np.float32)
    for index, ((x0, y0), (x1, y1)) in enumerate(zip(points0, initial_points1)):
        sx, sy = int(round(x0)), int(round(y0))
        if sx - half < 0 or sy - half < 0 or sx + half >= source.shape[1] or sy + half >= source.shape[0]:
            continue
        template = src_grad[sy - half : sy + half + 1, sx - half : sx + half + 1]
        cx, cy = int(round(x1)), int(round(y1))
        score_map = np.full((2 * search_radius + 1, 2 * search_radius + 1), -1.0, dtype=np.float32)
        for oy in range(-search_radius, search_radius + 1):
            for ox in range(-search_radius, search_radius + 1):
                tx, ty = cx + ox, cy + oy
                if tx - half < 0 or ty - half < 0 or tx + half >= reference.shape[1] or ty + half >= reference.shape[0]:
                    continue
                candidate = ref_grad[ty - half : ty + half + 1, tx - half : tx + half + 1]
                score_map[oy + search_radius, ox + search_radius] = _ncc(template, candidate)
        best_y, best_x = np.unravel_index(int(np.argmax(score_map)), score_map.shape)
        dx = best_x - search_radius
        dy = best_y - search_radius
        sub_x = sub_y = 0.0
        if 0 < best_x < score_map.shape[1] - 1:
            sub_x = _quadratic_offset(score_map[best_y, best_x - 1], score_map[best_y, best_x], score_map[best_y, best_x + 1])
        if 0 < best_y < score_map.shape[0] - 1:
            sub_y = _quadratic_offset(score_map[best_y - 1, best_x], score_map[best_y, best_x], score_map[best_y + 1, best_x])
        refined[index] = (cx + dx + sub_x, cy + dy + sub_y)
        scores[index] = score_map[best_y, best_x]
    return refined, scores

