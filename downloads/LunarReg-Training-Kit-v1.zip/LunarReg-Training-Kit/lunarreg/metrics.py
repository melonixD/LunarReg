from __future__ import annotations

import numpy as np

from .geometry import coverage_ratio, homography_errors, transform_points


def correspondence_metrics(
    points0: np.ndarray,
    points1: np.ndarray,
    ground_truth_h: np.ndarray,
    image_shape,
) -> dict:
    if len(points0) == 0:
        return {
            "match_count": 0,
            "mean_error": float("inf"),
            "median_error": float("inf"),
            "pck_1": 0.0,
            "pck_3": 0.0,
            "coverage": 0.0,
        }
    truth = transform_points(points0, ground_truth_h)
    errors = np.linalg.norm(truth - points1, axis=1)
    return {
        "match_count": int(len(points0)),
        "mean_error": float(errors.mean()),
        "median_error": float(np.median(errors)),
        "pck_1": float(np.mean(errors <= 1.0)),
        "pck_3": float(np.mean(errors <= 3.0)),
        "coverage": float(coverage_ratio(points0, image_shape)),
    }


def registration_metrics(points0, points1, homography, inliers, image_shape) -> dict:
    selected0 = points0[inliers]
    selected1 = points1[inliers]
    errors = homography_errors(selected0, selected1, homography) if len(selected0) else np.array([])
    return {
        "matches": int(len(points0)),
        "inliers": int(np.sum(inliers)),
        "inlier_ratio": float(np.mean(inliers)) if len(inliers) else 0.0,
        "rmse": float(np.sqrt(np.mean(errors**2))) if len(errors) else float("inf"),
        "median_error": float(np.median(errors)) if len(errors) else float("inf"),
        "coverage": float(coverage_ratio(selected0, image_shape)),
    }

