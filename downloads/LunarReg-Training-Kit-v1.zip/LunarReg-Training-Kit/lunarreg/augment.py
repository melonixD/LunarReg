from __future__ import annotations

import math
from typing import Tuple

import numpy as np


def _fade(t: np.ndarray) -> np.ndarray:
    return 6 * t**5 - 15 * t**4 + 10 * t**3


def perlin_noise_2d(
    shape: Tuple[int, int],
    resolution: Tuple[int, int],
    rng: np.random.Generator,
) -> np.ndarray:
    """Generate true gradient Perlin noise with values approximately in [-1, 1]."""
    height, width = shape
    res_y, res_x = resolution
    if height % res_y or width % res_x:
        raise ValueError("shape must be divisible by the Perlin resolution")

    angles = rng.uniform(0.0, 2.0 * math.pi, size=(res_y + 1, res_x + 1))
    gradients = np.stack((np.cos(angles), np.sin(angles)), axis=-1)

    yy, xx = np.meshgrid(
        np.arange(height, dtype=np.float32) * res_y / height,
        np.arange(width, dtype=np.float32) * res_x / width,
        indexing="ij",
    )
    y0 = np.floor(yy).astype(np.int32)
    x0 = np.floor(xx).astype(np.int32)
    yf = yy - y0
    xf = xx - x0

    def dot_grid(dy: int, dx: int) -> np.ndarray:
        grad = gradients[y0 + dy, x0 + dx]
        offset_x = xf - dx
        offset_y = yf - dy
        return grad[..., 0] * offset_x + grad[..., 1] * offset_y

    n00 = dot_grid(0, 0)
    n10 = dot_grid(0, 1)
    n01 = dot_grid(1, 0)
    n11 = dot_grid(1, 1)
    u = _fade(xf)
    v = _fade(yf)
    nx0 = n00 * (1.0 - u) + n10 * u
    nx1 = n01 * (1.0 - u) + n11 * u
    noise = nx0 * (1.0 - v) + nx1 * v
    scale = np.max(np.abs(noise)) + 1e-6
    return (noise / scale).astype(np.float32)


def fractal_perlin(
    shape: Tuple[int, int],
    rng: np.random.Generator,
    octaves: Tuple[int, ...] = (2, 4, 8),
    persistence: float = 0.5,
) -> np.ndarray:
    result = np.zeros(shape, dtype=np.float32)
    amplitude = 1.0
    total = 0.0
    for frequency in octaves:
        result += amplitude * perlin_noise_2d(shape, (frequency, frequency), rng)
        total += amplitude
        amplitude *= persistence
    result /= max(total, 1e-6)
    return np.clip(result, -1.0, 1.0)


def apply_perlin_illumination(
    image: np.ndarray,
    rng: np.random.Generator,
    multiplicative: Tuple[float, float] = (0.05, 0.25),
    additive: Tuple[float, float] = (0.01, 0.08),
) -> np.ndarray:
    """Apply smooth illumination variation without changing geometry."""
    noise = fractal_perlin(image.shape[-2:], rng)
    alpha = rng.uniform(*multiplicative)
    beta = rng.uniform(*additive)
    augmented = image * (1.0 + alpha * noise) + beta * noise
    return np.clip(augmented, 0.0, 1.0).astype(np.float32)


def apply_directional_light(image: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    height, width = image.shape
    yy, xx = np.meshgrid(
        np.linspace(-1.0, 1.0, height, dtype=np.float32),
        np.linspace(-1.0, 1.0, width, dtype=np.float32),
        indexing="ij",
    )
    angle = rng.uniform(0.0, 2.0 * math.pi)
    strength = rng.uniform(-0.35, 0.35)
    plane = 1.0 + strength * (math.cos(angle) * xx + math.sin(angle) * yy)
    return np.clip(image * plane, 0.0, 1.0).astype(np.float32)


def photometric_augment(image: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    import cv2

    result = image.astype(np.float32)
    gamma = rng.uniform(0.55, 1.75)
    result = np.power(np.clip(result, 0.0, 1.0), gamma)
    result = np.clip(result * rng.uniform(0.7, 1.3) + rng.uniform(-0.12, 0.12), 0.0, 1.0)
    result = apply_directional_light(result, rng)
    if rng.random() < 0.85:
        result = apply_perlin_illumination(result, rng)
    if rng.random() < 0.55:
        sigma = float(rng.uniform(0.2, 1.8))
        result = cv2.GaussianBlur(result, (0, 0), sigmaX=sigma)
    if rng.random() < 0.5:
        std = rng.uniform(0.002, 0.035)
        result = result + rng.normal(0.0, std, size=result.shape).astype(np.float32)
    return np.clip(result, 0.0, 1.0).astype(np.float32)


def sample_homography(
    size: int,
    rng: np.random.Generator,
    difficulty: float = 1.0,
) -> np.ndarray:
    """Sample a source-to-reference homography for a square image."""
    import cv2

    d = float(np.clip(difficulty, 0.0, 1.0))
    margin = size * (0.04 + 0.18 * d)
    src = np.array(
        [[0, 0], [size - 1, 0], [size - 1, size - 1], [0, size - 1]],
        dtype=np.float32,
    )
    jitter = rng.uniform(-margin, margin, size=(4, 2)).astype(np.float32)
    center = np.array([[(size - 1) / 2, (size - 1) / 2]], dtype=np.float32)
    angle = math.radians(rng.uniform(-(8 + 27 * d), 8 + 27 * d))
    log_scale = rng.uniform(-math.log(1.0 + 0.35 * d), math.log(1.0 + 0.35 * d))
    scale = math.exp(log_scale)
    rotation = np.array(
        [[math.cos(angle), -math.sin(angle)], [math.sin(angle), math.cos(angle)]],
        dtype=np.float32,
    )
    transformed = (src - center) @ rotation.T * scale + center
    translation = rng.uniform(-0.12 * d * size, 0.12 * d * size, size=(1, 2))
    dst = transformed + translation + jitter
    return cv2.getPerspectiveTransform(src, dst.astype(np.float32)).astype(np.float32)


def warp_image(image: np.ndarray, homography: np.ndarray, size: int) -> Tuple[np.ndarray, np.ndarray]:
    import cv2

    warped = cv2.warpPerspective(
        image,
        homography,
        (size, size),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )
    ones = np.ones_like(image, dtype=np.uint8)
    valid = cv2.warpPerspective(
        ones,
        homography,
        (size, size),
        flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )
    return warped.astype(np.float32), valid.astype(np.float32)

