from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F


class ConvNormAct(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1) -> None:
        super().__init__(
            nn.Conv2d(in_channels, out_channels, 3, stride=stride, padding=1, bias=False),
            nn.GroupNorm(min(8, out_channels), out_channels),
            nn.GELU(),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.GroupNorm(min(8, out_channels), out_channels),
            nn.GELU(),
        )


class FeatureEncoder(nn.Module):
    def __init__(self, dimension: int = 128) -> None:
        super().__init__()
        widths = [32, 48, 72, dimension]
        blocks = []
        in_channels = 1
        for width in widths:
            blocks.append(ConvNormAct(in_channels, width, stride=2))
            in_channels = width
        self.network = nn.Sequential(*blocks)

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        return self.network(image)


def sine_position_encoding(height: int, width: int, dimension: int, device, dtype) -> torch.Tensor:
    if dimension % 4:
        raise ValueError("feature dimension must be divisible by four")
    y, x = torch.meshgrid(
        torch.linspace(0.0, 1.0, height, device=device, dtype=dtype),
        torch.linspace(0.0, 1.0, width, device=device, dtype=dtype),
        indexing="ij",
    )
    frequencies = torch.exp(
        torch.linspace(0.0, math.log(1000.0), dimension // 4, device=device, dtype=dtype)
    )
    x = x.reshape(-1, 1) * frequencies.reshape(1, -1)
    y = y.reshape(-1, 1) * frequencies.reshape(1, -1)
    return torch.cat([torch.sin(x), torch.cos(x), torch.sin(y), torch.cos(y)], dim=1)


class CrossAttentionBlock(nn.Module):
    def __init__(self, dimension: int, heads: int, dropout: float) -> None:
        super().__init__()
        self.self0 = nn.MultiheadAttention(dimension, heads, dropout=dropout, batch_first=True)
        self.self1 = nn.MultiheadAttention(dimension, heads, dropout=dropout, batch_first=True)
        self.cross01 = nn.MultiheadAttention(dimension, heads, dropout=dropout, batch_first=True)
        self.cross10 = nn.MultiheadAttention(dimension, heads, dropout=dropout, batch_first=True)
        self.norms = nn.ModuleList([nn.LayerNorm(dimension) for _ in range(6)])
        self.ff0 = nn.Sequential(
            nn.Linear(dimension, 4 * dimension), nn.GELU(), nn.Dropout(dropout), nn.Linear(4 * dimension, dimension)
        )
        self.ff1 = nn.Sequential(
            nn.Linear(dimension, 4 * dimension), nn.GELU(), nn.Dropout(dropout), nn.Linear(4 * dimension, dimension)
        )

    def forward(self, tokens0: torch.Tensor, tokens1: torch.Tensor):
        query0 = self.norms[0](tokens0)
        query1 = self.norms[1](tokens1)
        tokens0 = tokens0 + self.self0(query0, query0, query0, need_weights=False)[0]
        tokens1 = tokens1 + self.self1(query1, query1, query1, need_weights=False)[0]
        query0 = self.norms[2](tokens0)
        query1 = self.norms[3](tokens1)
        update0 = self.cross01(query0, query1, query1, need_weights=False)[0]
        update1 = self.cross10(query1, query0, query0, need_weights=False)[0]
        tokens0 = tokens0 + update0
        tokens1 = tokens1 + update1
        tokens0 = tokens0 + self.ff0(self.norms[4](tokens0))
        tokens1 = tokens1 + self.ff1(self.norms[5](tokens1))
        return tokens0, tokens1


class LunarDenseMatcher(nn.Module):
    """Detector-free dense coarse matcher with continuous soft-argmax coordinates."""

    stride = 16

    def __init__(self, dimension: int = 128, heads: int = 4, layers: int = 2, dropout: float = 0.0) -> None:
        super().__init__()
        self.dimension = dimension
        self.encoder = FeatureEncoder(dimension)
        self.blocks = nn.ModuleList(
            [CrossAttentionBlock(dimension, heads, dropout) for _ in range(layers)]
        )
        self.projection = nn.Linear(dimension, dimension, bias=False)
        self.logit_scale = nn.Parameter(torch.tensor(math.log(10.0)))

    def forward(self, image0: torch.Tensor, image1: torch.Tensor) -> dict:
        feature0 = self.encoder(image0)
        feature1 = self.encoder(image1)
        batch, channels, height, width = feature0.shape
        tokens0 = feature0.flatten(2).transpose(1, 2)
        tokens1 = feature1.flatten(2).transpose(1, 2)
        position = sine_position_encoding(height, width, channels, image0.device, feature0.dtype)
        tokens0 = tokens0 + position.unsqueeze(0)
        tokens1 = tokens1 + position.unsqueeze(0)
        for block in self.blocks:
            tokens0, tokens1 = block(tokens0, tokens1)
        tokens0 = F.normalize(self.projection(tokens0), dim=-1)
        tokens1 = F.normalize(self.projection(tokens1), dim=-1)
        scale = self.logit_scale.exp().clamp(1.0, 100.0)
        logits = torch.einsum("bnc,bmc->bnm", tokens0, tokens1) * scale
        return {"logits": logits, "grid_height": height, "grid_width": width}

    @torch.no_grad()
    def matches(self, image0: torch.Tensor, image1: torch.Tensor, confidence_threshold: float = 0.05) -> dict:
        output = self(image0, image1)
        logits = output["logits"]
        probability = torch.softmax(logits, dim=-1) * torch.softmax(logits, dim=-2)
        forward_score, forward_index = probability.max(dim=-1)
        backward_index = probability.max(dim=-2).indices
        batch, count = forward_index.shape
        source_index = torch.arange(count, device=logits.device).unsqueeze(0).expand(batch, -1)
        mutual = backward_index.gather(1, forward_index) == source_index
        keep = mutual & (forward_score >= confidence_threshold)
        width = output["grid_width"]
        results = []
        for batch_index in range(batch):
            src = source_index[batch_index][keep[batch_index]]
            dst = forward_index[batch_index][keep[batch_index]]
            conf = forward_score[batch_index][keep[batch_index]]
            points0 = torch.stack(
                [(src % width + 0.5) * self.stride, (src // width + 0.5) * self.stride], dim=-1
            )
            points1 = torch.stack(
                [(dst % width + 0.5) * self.stride, (dst // width + 0.5) * self.stride], dim=-1
            )
            results.append({"points0": points0, "points1": points1, "confidence": conf})
        return {"batches": results, **output}

