from __future__ import annotations

import platform

import cv2
import kornia
import numpy
import torch


print("Python:", platform.python_version())
print("PyTorch:", torch.__version__)
print("Kornia:", kornia.__version__)
print("OpenCV:", cv2.__version__)
print("NumPy:", numpy.__version__)
print("CUDA available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print("GPU:", torch.cuda.get_device_name(0))
    print("VRAM GB:", round(torch.cuda.get_device_properties(0).total_memory / 2**30, 2))

