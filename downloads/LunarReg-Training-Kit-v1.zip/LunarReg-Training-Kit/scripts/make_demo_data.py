from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np

from lunarreg.augment import apply_perlin_illumination, sample_homography, warp_image


def crater_image(size: int, rng: np.random.Generator) -> np.ndarray:
    yy, xx = np.meshgrid(np.arange(size), np.arange(size), indexing="ij")
    image = np.full((size, size), 0.48, dtype=np.float32)
    image += 0.10 * (xx / size) - 0.08 * (yy / size)
    for _ in range(24):
        cx, cy = rng.uniform(0, size, size=2)
        radius = rng.uniform(size * 0.018, size * 0.12)
        distance = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
        bowl = -rng.uniform(0.04, 0.16) * np.exp(-((distance / radius) ** 2))
        rim = rng.uniform(0.05, 0.18) * np.exp(-(((distance - radius) / max(radius * 0.16, 1.0)) ** 2))
        shadow = -rng.uniform(0.03, 0.12) * np.exp(
            -(((xx - (cx + radius * 0.28)) ** 2 + (yy - (cy + radius * 0.12)) ** 2) / (radius**2 + 1))
        )
        image += bowl + rim + shadow
    image += rng.normal(0.0, 0.015, size=image.shape).astype(np.float32)
    image = cv2.GaussianBlur(image, (0, 0), 0.7)
    return np.clip(image, 0.0, 1.0)


def main() -> None:
    root = Path("data/demo")
    train = root / "train"
    train.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(2026)
    for index in range(16):
        image = crater_image(128, rng)
        cv2.imwrite(str(train / f"crater_{index:03d}.png"), (image * 255).astype(np.uint8))
    source = crater_image(128, rng)
    homography = sample_homography(128, rng, difficulty=0.2)
    reference, _ = warp_image(source, homography, 128)
    reference = apply_perlin_illumination(reference, rng, (0.08, 0.14), (0.01, 0.04))
    cv2.imwrite(str(root / "source.png"), (source * 255).astype(np.uint8))
    cv2.imwrite(str(root / "reference.png"), (reference * 255).astype(np.uint8))
    with open(root / "ground_truth.json", "w", encoding="utf-8") as handle:
        json.dump({"source_to_reference": homography.tolist()}, handle, indent=2)
    print(f"Demo data written to {root}")


if __name__ == "__main__":
    main()

