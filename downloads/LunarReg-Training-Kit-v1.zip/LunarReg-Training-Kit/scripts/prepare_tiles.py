from __future__ import annotations

import argparse
import csv
from pathlib import Path

import cv2
import numpy as np


EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}


def normalize(image: np.ndarray) -> np.ndarray:
    if image.ndim == 3:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    image = image.astype(np.float32)
    low, high = np.percentile(image, [1.0, 99.0])
    return np.clip((image - low) / max(high - low, 1e-6), 0.0, 1.0)


def starts(length: int, size: int, overlap: int):
    if length <= size:
        return [0]
    step = size - overlap
    values = list(range(0, max(1, length - size + 1), step))
    if values[-1] != length - size:
        values.append(length - size)
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--size", type=int, default=512)
    parser.add_argument("--overlap", type=int, default=64)
    parser.add_argument("--min-std", type=float, default=0.025)
    args = parser.parse_args()
    source_root = Path(args.input)
    output_root = Path(args.output)
    output_root.mkdir(parents=True, exist_ok=True)
    images = sorted(path for path in source_root.rglob("*") if path.suffix.lower() in EXTENSIONS)
    rows = []
    for image_path in images:
        raw = cv2.imread(str(image_path), cv2.IMREAD_UNCHANGED)
        if raw is None:
            print(f"Skipping unreadable file: {image_path}")
            continue
        image = normalize(raw)
        if image.shape[0] < args.size or image.shape[1] < args.size:
            image = cv2.copyMakeBorder(
                image,
                0,
                max(0, args.size - image.shape[0]),
                0,
                max(0, args.size - image.shape[1]),
                cv2.BORDER_REFLECT_101,
            )
        stem = image_path.stem.replace(" ", "_")
        for top in starts(image.shape[0], args.size, args.overlap):
            for left in starts(image.shape[1], args.size, args.overlap):
                tile = image[top : top + args.size, left : left + args.size]
                if float(tile.std()) < args.min_std:
                    continue
                name = f"{stem}_y{top:06d}_x{left:06d}.png"
                cv2.imwrite(str(output_root / name), (tile * 255).astype(np.uint8))
                rows.append([name, str(image_path), left, top, args.size, float(tile.std())])
    with open(output_root / "tiles.csv", "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["tile", "parent", "left", "top", "size", "std"])
        writer.writerows(rows)
    print(f"Created {len(rows)} tiles in {output_root}")


if __name__ == "__main__":
    main()

