from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import cv2
import kornia as K
import numpy as np
import torch
from kornia.feature import LoFTR

from lunarreg.geometry import estimate_homography


def load_tensor(path: str, size: int, device):
    image = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise RuntimeError(f"Could not read {path}")
    original_shape = image.shape
    resized = cv2.resize(image, (size, size), interpolation=cv2.INTER_AREA)
    tensor = torch.from_numpy(resized).float()[None, None].to(device) / 255.0
    return image, tensor, original_shape


def draw_preview(source, reference, points0, points1, inliers):
    height = max(source.shape[0], reference.shape[0])
    canvas = np.zeros((height, source.shape[1] + reference.shape[1], 3), dtype=np.uint8)
    canvas[: source.shape[0], : source.shape[1]] = cv2.cvtColor(source, cv2.COLOR_GRAY2BGR)
    canvas[: reference.shape[0], source.shape[1] :] = cv2.cvtColor(reference, cv2.COLOR_GRAY2BGR)
    for p0, p1, keep in zip(points0, points1, inliers):
        if not keep:
            continue
        a = tuple(np.round(p0).astype(int))
        b = tuple((np.round(p1) + np.array([source.shape[1], 0])).astype(int))
        cv2.line(canvas, a, b, (50, 220, 80), 1, cv2.LINE_AA)
    return canvas


def main() -> None:
    parser = argparse.ArgumentParser(description="Create manually reviewable OHRC-LRO pseudo-labels")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--preview-dir", required=True)
    parser.add_argument("--size", type=int, default=640)
    parser.add_argument("--confidence", type=float, default=0.45)
    parser.add_argument("--min-inliers", type=int, default=20)
    args = parser.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    matcher = LoFTR(pretrained="outdoor").eval().to(device)
    preview_dir = Path(args.preview_dir)
    preview_dir.mkdir(parents=True, exist_ok=True)
    accepted = []
    with open(args.manifest, newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        source, tensor0, shape0 = load_tensor(row["source_path"], args.size, device)
        reference, tensor1, shape1 = load_tensor(row["reference_path"], args.size, device)
        with torch.no_grad():
            result = matcher({"image0": tensor0, "image1": tensor1})
        points0 = result["keypoints0"].cpu().numpy()
        points1 = result["keypoints1"].cpu().numpy()
        confidence = result["confidence"].cpu().numpy()
        keep = confidence >= args.confidence
        points0, points1 = points0[keep], points1[keep]
        points0 *= np.array([shape0[1] / args.size, shape0[0] / args.size], dtype=np.float32)
        points1 *= np.array([shape1[1] / args.size, shape1[0] / args.size], dtype=np.float32)
        homography, inliers = estimate_homography(points0, points1, threshold=3.0)
        pair_id = row.get("pair_id") or f"pair_{len(accepted):05d}"
        if homography is None or int(inliers.sum()) < args.min_inliers:
            print(f"Rejected {pair_id}: insufficient geometric support")
            continue
        preview = draw_preview(source, reference, points0, points1, inliers)
        cv2.imwrite(str(preview_dir / f"{pair_id}.jpg"), preview)
        accepted.append(
            {
                "pair_id": pair_id,
                "source_path": row["source_path"],
                "reference_path": row["reference_path"],
                "split": row.get("split", "train"),
                "homography": json.dumps(homography.tolist(), separators=(",", ":")),
                "inliers": int(inliers.sum()),
                "review_status": "REVIEW_REQUIRED",
            }
        )
    fieldnames = ["pair_id", "source_path", "reference_path", "split", "homography", "inliers", "review_status"]
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(accepted)
    print(f"Created {len(accepted)} pseudo-labelled pairs. Review every preview before training.")


if __name__ == "__main__":
    main()

